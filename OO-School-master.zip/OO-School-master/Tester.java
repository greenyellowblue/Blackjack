
public class Tester {
	public static void main(String[] args)
	{
		int a = 2;
		double b = 3.01;
		
		System.out.println("Number of students in school: " + Student.get_studentNumber());
		Student student1 = new Student("Mister", "Chow", 101, 76);
		System.out.println("Number of students in school: " + Student.get_studentNumber());
		Student student2 = new Student("Parry", "Hotter", 102, 57);
		System.out.println("Number of students in school: " + Student.get_studentNumber());
		Student student3 = new Student("Tonald", "Drump", 103, 7);
		System.out.println("Number of students in school: " + Student.get_studentNumber());
		Student student4 = new Student("Tustin", "Jrudeau", 104, 63);
		System.out.println("Number of students in school: " + Student.get_studentNumber());
		adding(a, b);
		Teacher teacher1 = new Teacher("H", "Chow", 1, 50000, "Computer Studies", 208);
		Admin admin1 = new Admin("P", "Obadia", 2, 150000, "Principal", 101);
		System.out.println("First Name: "+ teacher1.get_firstName());
		System.out.println("Last Name: " + teacher1.get_lastName());
		System.out.println("Employee ID: "+ teacher1.get_employeeID());
		System.out.println("Annual Salary: "+ teacher1.get_salary());
		System.out.println("Department: "+ teacher1.get_department());
		System.out.println("Homeroom: "+ teacher1.get_homeroom());
		System.out.println("\nFirst Name: "+ admin1.get_firstName());
		System.out.println("Last Name: " + admin1.get_lastName());
		System.out.println("Employee ID: "+ admin1.get_employeeID());
		System.out.println("Annual Salary: "+ admin1.get_salary());
		System.out.println("Position: "+ admin1.get_position());
		System.out.println("Extension: "+ admin1.get_extension());
	}
	private static void adding(double x, double y){
		System.out.println(x + y);
	}
}
