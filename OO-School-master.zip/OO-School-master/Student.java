
public class Student {
	private String firstName;
	private String lastName;
	private int id;
	private int grade;
	private static double overallAverage;
	private static int numStudents = 0;
	private static double totalAverage = 0;
	
	public Student(String firstName, String lastName, int id, int grade){
		this.firstName = firstName;
		this.lastName = lastName;
		this.id = id;
		this.grade = grade;
		totalAverage += grade;
		numStudents++;
		overallAverage = totalAverage/numStudents;
	}
	public String get_firstName(){
		return firstName;
	}
	
	public void gradeBoost(){
		if(grade * 1.01 <= 100){
			grade *= 1.01;
		} else {
			grade = 100;
		}
	}
	public void setGrade(int grade){
		totalAverage = totalAverage - this.grade + grade;
		this.grade = grade;
		overallAverage = totalAverage/numStudents;
	}
	public static double get_overallAverage(){
		return overallAverage;
	}
	public String toString(){
		return "Student " + firstName + " with grade " + grade;
	}
	public static int get_studentNumber(){
		return numStudents;
	}
}
