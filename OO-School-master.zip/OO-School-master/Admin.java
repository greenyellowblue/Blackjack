
public class Admin extends Employee 
{
	private String position;
	private int extension;
	
	public String get_position(){
		return position;
	}
	public int get_extension(){
		return extension;
	}
	
	public Admin(String f, String l, int id, int s, String pos, int ext){
		super(f,l,id,s);
		position = pos;
		extension = ext;
	}
}
